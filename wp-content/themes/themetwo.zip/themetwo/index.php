<?php get_header() ?>




   <?php get_template_part( 'template/home') ?>
   <?php get_template_part( 'template/about') ?>
   <?php get_template_part( 'template/services') ?>
   <?php get_template_part( 'template/works') ?>
   <?php get_template_part( 'template/clients') ?>
   <?php get_template_part( 'template/testimonials') ?>
   <?php get_template_part( 'template/contact') ?>


    <?php get_footer() ?>