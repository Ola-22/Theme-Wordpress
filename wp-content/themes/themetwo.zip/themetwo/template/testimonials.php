
    <!-- testimonies
    ================================================== -->
    <section class="s-testimonials">

        <div class="testimonials__icon" data-aos="fade-up"></div>

        <?php dynamic_sidebar( 'testimonial-sidebar' ) ?>

    </section> <!-- end s-testimonials -->